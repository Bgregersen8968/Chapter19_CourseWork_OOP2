/*
Author: Brayden G.
Date: 1/22/2024

Description: 
 */
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

public class Exercise19_03 {
  public static void main(String[] args) {
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(14);
    list.add(24);
    list.add(14);
    list.add(42);
    list.add(25);
    
    ArrayList<Integer> newList = removeDuplicates(list);
    
    System.out.print(newList);
  }
  public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list){
	 LinkedHashSet<E> newList = new LinkedHashSet<> (list);
	 return new ArrayList<>(newList);
	
	
  }
}